package MyPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import AbstractComponents.AbstractComponent;

public class CheckoutPage extends AbstractComponent {
	WebDriver driver;
	JavascriptExecutor js;

	public CheckoutPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		js = (JavascriptExecutor) driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "a.action__submit")
	WebElement placeorder;

	@FindBy(css = "input[placeholder='Select Country']")
	WebElement selectCountry;

	@FindBy(css = ".ta-results button")
	List<WebElement> CountryList;

	By search = By.cssSelector("section.ta-results.list-group.ng-star-inserted");

	public void selectcountry(String CountryName) {
		Actions actions = new Actions(driver);
		actions.sendKeys(selectCountry, CountryName).build().perform();
		waitforElementToAppear(search);

		for (WebElement country : CountryList) {
			if (country.getText().trim().equals("India")) {
				js.executeScript("arguments[0].scrollIntoView(true);", country);
				js.executeScript("arguments[0].click();", country);
				break;
			}
		}
	}

	public void submitorder() {
		js.executeScript("arguments[0].scrollIntoView(true);", placeorder);
		js.executeScript("arguments[0].click();", placeorder);
	}

}
