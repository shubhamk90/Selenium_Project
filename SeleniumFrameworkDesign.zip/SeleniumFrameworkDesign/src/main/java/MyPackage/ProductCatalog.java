package MyPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import AbstractComponents.AbstractComponent;

public class ProductCatalog extends AbstractComponent {
	WebDriver driver;

	public ProductCatalog(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this); 
	}

	@FindBy(css = "div.mb-3")
	List<WebElement> products;
	
	

	By Byproducts = By.cssSelector("div.mb-3");
	By spinner = By.cssSelector("div.ngx-spinner-overlay");  
	
	public List<WebElement> getproductList() {
		waitforElementToAppear(Byproducts);
		return products;
	}

	WebElement finalprod;

	public WebElement getProductName(String productname) {
		finalprod = products.stream().filter(
				product -> product.findElement(By.cssSelector("b")).getText().trim().equalsIgnoreCase(productname))
				.findFirst().orElse(null);

		return finalprod;
	}

	public void addProductToCart(String productname) {
		finalprod = getProductName(productname); 
		finalprod.findElement(By.cssSelector("button[class='btn w-10 rounded']")).click();
		waitforElementToDisappear(spinner);   
	}

}





