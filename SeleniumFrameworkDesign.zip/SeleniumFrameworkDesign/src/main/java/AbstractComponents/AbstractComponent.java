// Re-usable utilities

package AbstractComponents;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AbstractComponent {
	WebDriver driver;

	public AbstractComponent(WebDriver driver) {
		this.driver = driver;
	}

	public void waitforElementToAppear(By findid) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(findid));
	}

	public void waitforElementToDisappear(By spinner) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.invisibilityOfElementLocated(spinner));
	}

	@FindBy(css = "button[routerlink*='cart']")
	WebElement cartHeader;

	By spinner = By.cssSelector("div.ngx-spinner-overlay");

	public void GotoCartpage() {
		waitforElementToDisappear(spinner);
		cartHeader.click();
	}

}
