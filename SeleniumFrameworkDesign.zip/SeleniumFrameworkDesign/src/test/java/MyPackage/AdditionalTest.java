package MyPackage;
import java.io.IOException;
import org.testng.annotations.Test;

public class AdditionalTest extends BaseTest
{
	
	public void additionalTest() throws IOException
	{
	       // Initialize the driver 
			initializeDriver();
			
			
			// Landing Page
			LandingPage landingPage = new LandingPage(driver);
			landingPage.Goto();
			landingPage.LoginApplication("sk12@gmail.com", "Shettyacademy90@@");
	}	
	
	
	
}







