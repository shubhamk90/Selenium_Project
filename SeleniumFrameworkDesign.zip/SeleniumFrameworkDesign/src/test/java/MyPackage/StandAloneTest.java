package MyPackage;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Resources.DataReader;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.awt.Desktop.Action;
import java.io.File;
import java.io.IOException;
import java.lang.module.FindException;
import java.nio.charset.StandardCharsets;
import java.sql.Driver;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;
import javax.swing.text.StyledEditorKit.BoldAction;


public class StandAloneTest extends BaseTest 
{
	
	@Test(dataProvider = "getdata",groups = {"Purchase"} )
	public void submitorder(HashMap<String, String> input) throws IOException
	{		
		// Initialize the driver 
		initializeDriver();
		
		// Landing Page
		LandingPage landingPage = new LandingPage(driver);
		landingPage.Goto();
		landingPage.LoginApplication(input.get("email"), input.get("password")); 

		// ProductCatalog Page
//		String productname = "ADIDAS ORIGINAL";
		ProductCatalog productCatalog = new ProductCatalog(driver);
		productCatalog.getproductList();
		productCatalog.addProductToCart(input.get("productname"));
		productCatalog.GotoCartpage();

		// Cart Page
		CartPage cartPage = new CartPage(driver);
		Boolean match = cartPage.verifyProductDisplay(input.get("productname"));
		Assert.assertTrue(match);
		cartPage.Checkout();

		// Checkout Page
		String CountryName = "India";
		CheckoutPage checkout = new CheckoutPage(driver);
		checkout.selectcountry(CountryName);
		checkout.submitorder();

		// Confirmation Page
		ConfirmationPage confirm = new ConfirmationPage(driver);
		String confirm_message = confirm.confirmation();
		Assert.assertTrue(confirm_message.equalsIgnoreCase("Thankyou for the order."));	

	} 
	
	
	
	public void getScreenshot() throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot) driver;
		File sourceFile =  ts.getScreenshotAs(OutputType.FILE); 
		File destinationFile = new File("C:\\Users\\shubhak12\\Pictures\\Screenshots"); 
		FileUtils.copyFile(sourceFile, destinationFile); 
		
		
	}
	
	@DataProvider
	public Object[] [] getdata() throws IOException
	{ 
		
		DataReader reader = new DataReader();
		List<HashMap<String, String>> data =  reader.getJsonDataToMap(System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\PurchaseOrder.json");  
		return new Object [][] {{data.get(0)}, {data.get(1)}};  
		
		
		
		
//		HashMap<String, String> map = new HashMap<String, String>(); 
//		map.put("email", "sk12@gmail.com");
//		map.put("password", "Shettyacademy90@@");
//		map.put("productname", "ADIDAS ORIGINAL"); 
//		
//		HashMap<String, String> map1 = new HashMap<String, String>(); 
//		map1.put("email", "sk12@gmail.com");
//		map1.put("password", "Shettyacademy90@@");
//		map1.put("productname", "IPHONE 13 PRO"); 
//		
//		
//		return new Object [][] {{"sk12@gmail.com", "Shettyacademy90@@", "ADIDAS ORIGINAL"},{"sk12@gmail.com", "Shettyacademy90@@", "IPHONE 13 PRO"}}; 
//		
//		return new Object [][] {{map}, {map1}};
		
	}
	
	
	

}



/*
There are three parameters which we are sending [Parameterization Data provider], what if there are 15 parameters  
we cannot send 15 parameters and catch them in method it looks messey. 

So, we can send hashmaps inside the array. 
 
*/