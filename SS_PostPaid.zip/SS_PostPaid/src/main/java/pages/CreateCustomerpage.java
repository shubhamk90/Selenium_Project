package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.WaitUtils;

public class CreateCustomerpage {
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;

	// Constructor
	public CreateCustomerpage(WebDriver driver) 
	{
		this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
		this.js = (JavascriptExecutor) driver; 

	}
 
	By spinnerLocator = By.id("globalSpinnerARM");

	public void customercreation() {
		wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));

		// First Name
		WebElement firstName = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='First name']")));
		firstName.sendKeys("Shubham");

		// Last Name
		WebElement lastName = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Last name']")));
		lastName.sendKeys("Kumar");

		// Email
		WebElement email = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Email address']")));
		email.sendKeys("sh12@gmail.com");

		// Confirm Email
		WebElement confirmEmail = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.cssSelector("input[placeholder='Confirm email address']")));
		confirmEmail.sendKeys("sh12@gmail.com");

		// UK Mobile Number
		WebElement mobile = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='UK Mobile Number']")));
		mobile.clear();
		mobile.sendKeys("07123456789");

		// DOB Day
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Day']")))
				.sendKeys("09");

		// DOB Month
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Month']")))
				.sendKeys("11");

		// DOB Year
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Year']")))
				.sendKeys("1980");

		// Postcode
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Postcode']")))
				.sendKeys("RG7 4EE");

		// Click "Find Address"
		WebElement FindAddress = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Find address']"))); 
		js.executeScript("arguments[0].scrollIntoView({block: 'center'});", FindAddress);
		js.executeScript("arguments[0].click();", FindAddress);  

		// Click "Choose Address"
		wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));
		WebElement chooseaddress = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.cssSelector("input[placeholder='Choose your address']")));
		chooseaddress.click();

		// Wait for address suggestions to appear
		List<WebElement> addressOptions = wait.until(ExpectedConditions
				.visibilityOfAllElementsLocatedBy(By.xpath("//body//div[@role='presentation']//li[@role='option']")));

		System.out.println("Address Suggestions:");
		for (WebElement option : addressOptions) {
			System.out.println(">> " + option.getText().trim());
		}

		// Desired address to match
		String desiredAddress = "Abbots Farm, Sulhamstead Abbots, Sulhamstead, READING, RG7 4EE";
		boolean addressClicked = false;

		// Try to click the matching address
		for (WebElement option : addressOptions) {
			String optionText = option.getText().trim();

			if (desiredAddress.equalsIgnoreCase(optionText)) {
				option.click();
				System.out.println("Clicked on matched address: " + optionText);
				addressClicked = true;
				break;
			}
		}

		if (!addressClicked) {
			System.out.println("❌ Desired address not found in suggestions.");
			return;
		}

		// Wait for the selected address to appear in the Your-Address block
		WebElement selectedAddressBlock = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.your-selected-address")));
		String displayedAddress = selectedAddressBlock.getText().replace("Your address:", "").trim();

		// Flexible verification
		if (displayedAddress.contains("Abbots Farm")) {
			System.out.println("✅ Address verification successful.");
		} else {
			System.out.println("❌ Address verification failed.");
			System.out.println("Expected to contain: Abbots Farm");
			System.out.println("Found: " + displayedAddress);
		}

		// Moved Month
		WebElement Month = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[id='addressStartDate.month']")));
		Month.sendKeys("10");

		// Moved Year
		WebElement Year = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[id='addressStartDate.year']")));
		Year.sendKeys("2002");

		// Residence Status
		WebElement residence = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Residence status']")));
		residence.click();

		// Wait for residence suggestions to appear
		List<WebElement> residenceoptions = wait.until(ExpectedConditions
				.visibilityOfAllElementsLocatedBy(By.xpath("//body//div[@role='presentation']//li[@role='option']")));
		System.out.println("Printing Residence Options below: ");

		for (WebElement residencElement : residenceoptions) {
			System.out.println(residencElement.getText());
		}

		// Desired Status to match
		String desiredResidenceStatus = "Owner";
		boolean clicked = false;

		// Try to click the matching Status
		for (WebElement residencElement : residenceoptions) {
			String residenceoptionText = residencElement.getText().trim();

			if (desiredResidenceStatus.equalsIgnoreCase(residenceoptionText)) {
				residencElement.click();
				clicked = true;
				System.out.println("Clicked on matched Status: " + residenceoptionText);
				break;
			}
		}
		if (!addressClicked) {
			System.out.println("❌ Desired Residence status not found in suggestions.");
			return;
		}

		// Bank Account Details
		WebElement openMonth = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.cssSelector("input[id='BankDetailsSectionName.bankAccountSince.month']")));
		openMonth.sendKeys("09");

		WebElement openYear = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.cssSelector("input[id='BankDetailsSectionName.bankAccountSince.year']")));
		openYear.sendKeys("2002");

		// Employment type
		WebElement empElements = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[id='employmentType']")));
		empElements.click();

		// Printing list of Employment type
		List<WebElement> empList = wait.until(ExpectedConditions
				.visibilityOfAllElementsLocatedBy(By.xpath("//body//div[@role='presentation']//li[@role='option']")));
		for (WebElement empoption : empList) {
			System.out.println(empoption.getText());
		}

		// CLicking on desired type
		String desiredEmptype = "Employed";
		boolean clickedd = false;

		for (WebElement empoption : empList) {
			String empoptiontext = empoption.getText();

			if (desiredEmptype.equalsIgnoreCase(empoptiontext)) {
				empoption.click();
				clickedd = true;
				System.out.println("Clicked on matched Status: " + empoptiontext);
				break;
			}
		}
		if (!clickedd) {
			System.out.println("❌ Desired option is not availbale");
		}

		// Employment Status Your employment status
		WebElement empstatus = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.cssSelector("input[placeholder='Your employment status']")));
		empstatus.click();

		List<WebElement> empstatusList = wait.until(ExpectedConditions
				.visibilityOfAllElementsLocatedBy(By.xpath("//body//div[@role='presentation']//li[@role='option']")));
		for (WebElement empstatusoptions : empstatusList) {
			System.out.println(empstatusoptions.getText());
		}

		String expectedempstatus = "Senior Management";
		boolean statusclicked = false;
		for (WebElement empstatusoptions : empstatusList) {
			String emptext = empstatusoptions.getText();

			if (expectedempstatus.equalsIgnoreCase(emptext)) {
				empstatusoptions.click();
				statusclicked = true;
				System.out.println("Clicked on matched Status : " + emptext);
				break;
			}
		}

		if (!statusclicked) {
			System.out.println("❌ Desired option is not availbale");
		}

		// Employment start date
		WebElement empstartmonth = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.cssSelector("input[id='EmploymentDetailsSectionName.EmploymentStartDate.month']")));
		empstartmonth.sendKeys("09");

		WebElement empstartyear = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.cssSelector("input[id='EmploymentDetailsSectionName.EmploymentStartDate.year']")));
		empstartyear.sendKeys("2002");

		// Marital status
		WebElement maritalElement = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.cssSelector("input[placeholder='Your marital status']")));
		maritalElement.click();

		List<WebElement> maritalList = wait.until(ExpectedConditions
				.visibilityOfAllElementsLocatedBy(By.xpath("//body//div[@role='presentation']//li[@role='option']")));
		for (WebElement maritaloptions : maritalList) {
			System.out.println(maritaloptions.getText());
		}

		String expectedMaritalStatus = "Married";
		boolean MaritalClicked = false;

		for (WebElement maritaloptions : maritalList) {
			String maritaltext = maritaloptions.getText();

			if (expectedMaritalStatus.equalsIgnoreCase(maritaltext)) {
				maritaloptions.click();
				MaritalClicked = true;
				System.out.println("Clicked on matched Status : " + maritaltext);
				break;
			}
		}

		if (!MaritalClicked) {
			System.out.println("❌ Desired option is not availbale");
		}

		// Click on continue button
		driver.findElement(By.xpath("//button[text()='Continue']")).click();

	}
}
