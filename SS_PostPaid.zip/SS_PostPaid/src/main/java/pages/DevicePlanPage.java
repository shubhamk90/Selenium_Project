package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.WaitUtils;

import java.time.Duration;

public class DevicePlanPage 
{

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    // Constructor
    public DevicePlanPage(WebDriver driver) 
    {

        this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
        js = (JavascriptExecutor) driver;

    }

    
    // Spinner
    By spinnerLocator =  By.id("globalSpinnerARM");

    // 12 Months selection
    By default24Months = By.xpath("//div[text()='24 Months']/parent::div[contains(@class,'choice-card')]");
    By M12Months = By.xpath("//div[text()='12 Months']");
    By M12MonthsParentLocator = By.xpath("//div[text()='12 Months']/parent::div");

    // Data selection - 2GB
    By G2GB = By.xpath("//div[text()='2GB']");
    By G2GBParentLocator = By.xpath("//div[text()='2GB']/parent::div");

    // Plan selection - Lite
    By defaultLitePlan = By.xpath("//div[text()='Lite']/parent::div[contains(@class,'choice-card')]");
    By Lite_plan = By.xpath("//div[text()='Lite']");

    // Add-on plan
    By AddToPlan = By.cssSelector("button[value='2GB Lite Airtime 12M']");

    // Confirmation after selecting add-on
    By PlanSelectedText = By.xpath("//span[text()='Plan selected']");
    
    // Continue button
    By ContinueBtn = By.cssSelector("button[id='plans-page-continue-button']");

    public void selectDevicePlan() 
    {

        // 1. Wait for spinner to disappear
        wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));

        // 2. Wait for 24 Months DOM ready
        wait.until(ExpectedConditions.attributeContains(default24Months, "class", "selected"));

        // 3. Wait for 12 Months to appear
        wait.until(ExpectedConditions.presenceOfElementLocated(M12Months));

        // 4. Scroll and click 12 Months

        WebElement Months12 = wait.until(ExpectedConditions.elementToBeClickable(M12Months));
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", Months12);
        Months12.click();

        // 5. Wait for 12 Months to be selected
        wait.until(ExpectedConditions.attributeContains(M12MonthsParentLocator, "class", "selected"));

        // 6. Select 2GB Data
        WebElement GB2 = wait.until(ExpectedConditions.elementToBeClickable(G2GB));
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", GB2);
        GB2.click();
        wait.until(ExpectedConditions.attributeContains(G2GBParentLocator, "class", "selected"));

        // 7. Select Lite Plan
        wait.until(ExpectedConditions.attributeContains(defaultLitePlan, "class", "selected"));
        WebElement LitePlan = wait.until(ExpectedConditions.elementToBeClickable(Lite_plan));
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", LitePlan);
        LitePlan.click();

        // 8. Add plan
        WebElement add_this_plan = wait.until(ExpectedConditions.elementToBeClickable(AddToPlan));
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", add_this_plan);
        add_this_plan.click();

        // 9. Print Plan Selected confirmation
        WebElement PlanSelectedAppearance = wait.until(ExpectedConditions.elementToBeClickable(PlanSelectedText));
        System.out.println("Confirmation: " + PlanSelectedAppearance.getText());

        // 10. Click continue
        driver.findElement(ContinueBtn).click();

    }

} 
 