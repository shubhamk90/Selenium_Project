package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.WaitUtils;

public class AddonsPage 
{
	
	
	WebDriver driver;
	WebDriverWait wait;
    JavascriptExecutor js;

	// Constructor
	public AddonsPage(WebDriver driver) 
	{
		this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
        this.js = (JavascriptExecutor) driver;
  
	}
    
	
	// Locators
	
	By spinnerLocator = By.id("globalSpinnerARM");   
	
	public void AddOns()
	{
		wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));
		WebElement AddToBasket = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button[automation-id='addons-page-continue-button']")));
		js.executeScript("arguments[0].scrollIntoView({block: 'center'});", AddToBasket);
		
		WebElement AddtoBasketClickable = wait.until(ExpectedConditions.elementToBeClickable(AddToBasket));		
		js.executeScript("arguments[0].click();", AddtoBasketClickable);  
	}
	
	
}




