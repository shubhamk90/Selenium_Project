package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.WaitUtils;

import java.time.Duration;

public class DeviceRepaymentPage 
{

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    // Constructor
    public DeviceRepaymentPage(WebDriver driver) 
    {
        this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
        this.js = (JavascriptExecutor) driver;

    }

    
    // Locators

    By spinnerLocator = By.id("globalSpinnerARM"); // update as per your actual class
	By default36Locator = By.xpath("//div[text()='36 months']/parent::div[contains(@class,'choice-card')]");
    By payAllTodayLocator = By.xpath("//div[text()='Pay all today']");
    By payAllTodayParentLocator = By.xpath("//div[text()='Pay all today']/parent::div[contains(@class,'choice-card')]");
    By continueButton = By.cssSelector("button[id='deviceDetailsContinue']");

    
    // Actions

    public void selectPayAllTodayPlan() 
    {

        // 1. Wait for spinner to disappear
        wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));

        // 2. Wait for default selection (if any)
        wait.until(ExpectedConditions.attributeContains(default36Locator, "class", "selected"));

        // 3. Wait for 'Pay All Today' plan to appear
        wait.until(ExpectedConditions.presenceOfElementLocated(payAllTodayLocator));

        // 4. Scroll to 'Pay All Today'
        WebElement payAllToday = driver.findElement(payAllTodayLocator);
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", payAllToday);

        // 5. Click on 'Pay All Today'
        payAllToday.click();

        // 6. Wait until it's selected
        wait.until(ExpectedConditions.attributeContains(payAllTodayParentLocator, "class", "selected"));

    }

    
    public void clickContinue() 
    {
    	driver.findElement(continueButton).click();
    }

    
    
    public void completePlanSelection() 
    {
        selectPayAllTodayPlan();
        clickContinue();

    }

}



 