package pages;

import java.sql.Driver;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.WaitUtils;

public class DeliveryandPaymentPage 
{
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	
	// Constructor
	public DeliveryandPaymentPage(WebDriver driver)
	{
		this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
		this.js = (JavascriptExecutor) driver;
	}
	
	By spinnerLocator = By.id("globalSpinnerARM"); 
	By D_HomeDeliveryOption = By.xpath("//span[text()='Home delivery']/ancestor::div[contains(@class,'choice-card')]");
	By D_1st_class_letter = By.xpath("//span[text() ='1st Class Large Letter - £4.50']/ancestor::label[contains(@class,'radio-with-label-checked')]");
	By before1030Label = By.xpath("//span[contains(text(),'BEFORE 10:30')]"); 
	By before1030Label_Parent = By.xpath("//span[contains(text(),'BEFORE 10:30')]/ancestor::label");
	
	
	public void DeliveryandPayment()
	{	
		wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));

		// 1. Wait until HomeDeliveryOptionis marked as selected → means DOM ready
		wait.until(ExpectedConditions.visibilityOfElementLocated(D_HomeDeliveryOption));  
		
		// 2. wait until D_1st_class_letter is selected
		wait.until(ExpectedConditions.visibilityOfElementLocated(D_1st_class_letter));
		
		// 3. Now wait for BEFORE 10:30 to appear
		wait.until(ExpectedConditions.presenceOfElementLocated(before1030Label));
		
		// 4.  Scroll and click BEFORE 10:30
		WebElement labelElement = wait.until(ExpectedConditions.elementToBeClickable(before1030Label));
		js.executeScript("arguments[0].scrollIntoView({block: 'center'});", labelElement);
		labelElement.click();

		// 5. Wait until BEFORE 10:30 is selected 
		wait.until(ExpectedConditions.attributeContains(before1030Label_Parent, "class", "radio-with-label-checked"));
		
		
		
		driver.findElement(By.cssSelector("input[id='bankCode']")).sendKeys("000004"); 
		driver.findElement(By.cssSelector("input[id='accountNumber']")).sendKeys("12345677"); 
		driver.findElement(By.cssSelector("input[type='checkbox']")).click(); 
		driver.findElement(By.xpath("//button[text()='Continue']")).click(); 
		

		// 1. Wait for the modal to appear
		By creditModal = By.xpath("//div[@class='modal-header-text' and contains(text(),'Your credit check')]"); 
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(creditModal)); 
		
		// 2. Now wait for checkbox inside modal
		By checkbox = By.xpath("//span[@automation-id='delivery-page-cv-modal-confirm-details-provided-correct']");
		WebElement creditCheckbox = wait.until(ExpectedConditions.visibilityOfElementLocated(checkbox));
		creditCheckbox.click(); 
		
		// 3. Click continue
		driver.findElement(By.cssSelector("button[automation-id='perform-credit-check-continue-button']")).click(); 
		
		
		
	}
	

}
