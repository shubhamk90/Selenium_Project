package pages;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.WaitUtils;

public class Reviewbasketpage 
{
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	
	public Reviewbasketpage(WebDriver driver) 
	{
		this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
        this.js = (JavascriptExecutor) driver;

	}
	
	By spinnerLocator = By.id("globalSpinnerARM"); 
	
	public void basket()
	{
		wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));
		WebElement Checkout = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Checkout now']")));
		js.executeScript("arguments[0].scrollIntoView({block: 'center'});", Checkout);
		WebElement Checkout_button = wait.until(ExpectedConditions.elementToBeClickable(Checkout));
		js.executeScript("arguments[0].click();", Checkout_button); 
	}
	
	
	
	
}
