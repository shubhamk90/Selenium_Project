package pages;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import utilities.WaitUtils;


public class DeviceSelectionPage 
{

    WebDriver driver;
    WebDriverWait wait;

    // Constructor
    public DeviceSelectionPage(WebDriver driver) 
    {
        this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 

    }

    
    By appleDevice = By.xpath("//div[@class='image-card-label' and text()='Apple']");
    By searchBox = By.cssSelector("input[type='search']"); 
    By iphone15 = By.xpath("(//span[@class='product-card-header-text' and text()='Apple iPhone 15 Pro Max'])"); 
    
    public void selectAppleDevice() 
    {
        WebElement appleCard = wait.until(ExpectedConditions.visibilityOfElementLocated(appleDevice));
        appleCard.click();
        
        WebElement search = wait.until(ExpectedConditions.visibilityOfElementLocated(searchBox));
        search.click();
        
        WebElement phone = wait.until(ExpectedConditions.visibilityOfElementLocated(iphone15));
        phone.click();
        

    }

}
 
