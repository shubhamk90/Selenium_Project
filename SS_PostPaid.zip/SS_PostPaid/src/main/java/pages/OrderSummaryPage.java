package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import utilities.WaitUtils;

public class OrderSummaryPage 
{
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	
	public OrderSummaryPage(WebDriver driver)
	{
		this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
		this.js = (JavascriptExecutor) driver;
	}
	
	
	By spinnerLocator = By.id("globalSpinnerARM");
	
	public void order()
	{
		wait.until(ExpectedConditions.invisibilityOfElementLocated(spinnerLocator));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='alert-text']"))); 
		System.out.println(driver.findElement(By.xpath("//div[@class='alert-text']")).getText());  
		


		
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("globalSpinnerARM")));
		WebElement terms =  driver.findElement(By.cssSelector("span.MuiIconButton-label input[id='order-summary-terms-container-check-box']"));
		js.executeScript("arguments[0].scrollIntoView({block: 'center'});", terms);
		js.executeScript("arguments[0].click();", terms); 

		WebElement buynoWebElement = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[automation-id='order-summary-submit-button']")));
		js.executeScript("arguments[0].scrollIntoView({block: 'center'});", buynoWebElement);
		js.executeScript("arguments[0].click();", buynoWebElement);
	}
	
}
