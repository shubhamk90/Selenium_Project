package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.WaitUtils;


public class PaymentPage 
{
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	
	// Constructor
	public PaymentPage(WebDriver driver) 
	{
		this.driver = driver;
        this.wait = WaitUtils.getWait(driver); 
		js=(JavascriptExecutor) driver;
		
	}
	
	
	public void Payment()
	{
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("globalSpinnerARM")));
		WebElement payment =  driver.findElement(By.cssSelector("span.MuiIconButton-label input[name='paymentMethod']")); 
		js.executeScript("arguments[0].click();", payment);  
		
		

		// Step 1: Wait for iframe to be available and switch to it
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("globalSpinnerARM")));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe.not-fraud")));

		// Step 2: Wait for the button inside iframe and click it
		WebElement submitButton = wait.until(ExpectedConditions.elementToBeClickable(
		By.xpath("//button[@automation-id='order-summary-submit-payment-simulator-button']")));
		submitButton.click();
		driver.switchTo().defaultContent();
		
		// Step 3: 
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("globalSpinnerARM")));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe.not-fraud")));
		WebElement submit3dsButton = wait.until(ExpectedConditions.elementToBeClickable(
		By.xpath("//button[@automation-id='order-summary-submit-3ds-simulator-button']")));
		submit3dsButton.click();
		
		// Step 4: switch back to the main page if needed
		  driver.switchTo().defaultContent();
	}
	
}
