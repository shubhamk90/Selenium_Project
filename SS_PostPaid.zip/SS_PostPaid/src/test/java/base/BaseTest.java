package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest 
{

	protected WebDriver driver = new ChromeDriver();

    @BeforeClass
    public void setup() 
    {
		     driver.manage().deleteAllCookies(); 
    	     driver.manage().window().maximize(); 
		     driver.get("http://inlnqw7597:35000/shop/phones");
    }

    @AfterClass
    public void teardown() 
    {
    	if (driver != null) 
    	{
    		driver.quit();

        }

    }

}


