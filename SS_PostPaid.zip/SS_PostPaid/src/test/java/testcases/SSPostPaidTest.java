package testcases;

import org.testng.annotations.Test;
import pages.DeviceSelectionPage;
import pages.OrderSummaryPage;
import pages.PaymentPage;
import pages.Reviewbasketpage;
import pages.DeviceRepaymentPage;
import pages.AddonsPage;
import pages.CreateCustomerpage;
import pages.DeliveryandPaymentPage;
import pages.DevicePlanPage;
import base.BaseTest;



public class SSPostPaidTest extends BaseTest 
{

    @Test
    public void TestCases() 
    {

        // Step 1: Device Selection Page
        DeviceSelectionPage devicePage = new DeviceSelectionPage(driver);
        devicePage.selectAppleDevice();  

        // Step 2: Device Repayment Page
        DeviceRepaymentPage repaymentPage = new DeviceRepaymentPage(driver);
        repaymentPage.completePlanSelection();

        // Step 3: Device Plan Page
        DevicePlanPage planPage = new DevicePlanPage(driver);
        planPage.selectDevicePlan();

        // Step 4: Addons Page
        AddonsPage selectAddons = new AddonsPage(driver);
        selectAddons.AddOns();
        
        // Step 5: Reviewbasketpage
        Reviewbasketpage selectbasket = new Reviewbasketpage(driver);
        selectbasket.basket();
        
        // Step 6: CustomerCreation 
        CreateCustomerpage createcustomer = new CreateCustomerpage(driver);
        createcustomer.customercreation();
        
        // Step 7: Delivery and Payment Page
        DeliveryandPaymentPage deliverypayment = new DeliveryandPaymentPage(driver);
        deliverypayment.DeliveryandPayment();
        
        // Step 8: OrderSummaryPage
        OrderSummaryPage OrderSummary = new OrderSummaryPage(driver);
        OrderSummary.order(); 
        
        // Step 9: PaymentPage
        PaymentPage payment = new PaymentPage(driver);
        payment.Payment();
     
        
        
    }

}
 
