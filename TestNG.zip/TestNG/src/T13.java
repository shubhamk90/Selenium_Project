import java.security.PublicKey;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class T13 
{
	@Test
	public void Money()
	{
		System.out.println("Money"); 
	}
	
	@Test
	@Parameters({"URL"})	
	public void ParaMeter(@Optional("defaultURL") String nameurl)
	{
		System.out.println(nameurl);   
	}
	


	// Run this test using the data from the getdata Method 
	@Test(dataProvider = "getdata")
	public void data(String usernamee, String passwordd)
	{
		System.out.println(usernamee);
		System.out.println(passwordd); 
	}
	

	// This Method supplies test data.  
	@DataProvider
	public Object[][] getdata()
	{
		Object[][] data = new Object[3][2];
		data[0][0] = "firstusername";
		data[0][1] = "firspassword";
		
		data[1][0] = "secondusername";
		data[1][1] = "secondpassword";
		
		data[2][0] = "thirdusername";
		data[2][1] = "thirdpassword"; 
		
		return data; 
		
		
	}
	
}





