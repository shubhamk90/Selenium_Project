import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


@Listeners(T14.class)
public class T15 
{
	@Test
	public void TCS()
	{
		System.out.println("tcs");
		Assert.assertTrue(false); 
	}
	
	@Test
	public void GOOGLE()
	{
		System.out.println("Google"); 
	}
	
}

