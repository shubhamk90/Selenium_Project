package test;
import org.testng.annotations.Test;

public class SampleClass1
{
	@Test
	public void D()
	{
		System.out.println("D is in the test package");
	}
	
	@Test
	public void E()
	{
		System.out.println("E is in the test package"); 
	}
	
	@Test
	public void F()
	{
		System.out.println("F is in the test package"); 
	}
}
