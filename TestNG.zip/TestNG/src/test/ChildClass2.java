package test;

import org.testng.annotations.Test;

public class ChildClass2
{
	int a;
	
	public ChildClass2(int a) 
	{
		this.a=a;
	}
	
	@Test
	public int inc() 
	{
		this.a = a+1;
		return a; 
	}
	
}

