package test;
import org.testng.annotations.Test;

public class SampleClass2 
{
	@Test
	public void A()
	{
		System.out.println("A is in the test package");
	}
	
	@Test
	public void B()
	{
		System.out.println("B is in the test package"); 
	}
	
	@Test
	public void C()
	{
		System.out.println("C is in the test package"); 
	}
}
