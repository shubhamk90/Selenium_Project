package test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ParentClass 
{
	public void doThis()
	{
		System.out.println("I am here!"); 
	}
	
	@BeforeMethod
	public void beformethod()
	{
		System.out.println("runs before executing any test case");
	}
	
	public void doAgain()
	{
		System.out.println("Again ?");
	}
}





/*
I have created a Parent Class where i declared a method 
and in child class i am calling that method using inheritance concept.

*/