package test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ChildClass extends ParentClass
{
	@Test
	public void testRun()
	{
		doThis(); 
		doAgain();
		
		int a=3;
		ChildClass2 obj = new ChildClass2(a);
		System.out.println(obj.inc());
		 
		
		
	}
	
}






/*
Here child class extends parent class and we can 
call the method which we declared in parent class.

If we don't want to use inheritance then we have to 
made a object of parent class i child class to access the parent class method in child class. 

*/