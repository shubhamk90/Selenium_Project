import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class T1 
{
	@Test
	public void Firstsample()
	{
		System.out.println("First Test Case"); 
	}
	
	@Test
	public void SecondSample()
	{
		System.out.println("Second Test Case"); 
	}
	
	@BeforeTest
	public void cleanUP()
	{
		System.out.println("I will execute first before all the test case execute"); 
	}
	
}

