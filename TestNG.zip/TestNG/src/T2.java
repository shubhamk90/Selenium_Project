import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class T2 
{
	@AfterTest
	public void after()
	{
		System.out.println("I will execute after all test case will execute"); 
	}
	
	@Test
	public void sample()
	{
		System.out.println("Sample Example"); 
	}
}

