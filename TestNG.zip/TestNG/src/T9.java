import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

public class T9 
{
	@AfterGroups("Smoke")
	public void haha()
	{
		System.out.println("Say hahha after"); 
	}
	
	
	@Test(groups = {"Smoke"}) 
	public void India()
	{
		System.out.println("India");
	}
	
	@Test
	public void USA()
	{
		System.out.println("USA");
	}
	
	@Test
	public void Switzerland()
	{
		System.out.println("Switzerland"); 
	}
}
