// We can Parameterized the values and we can drive the data from your TestNG XML file.  


import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class T12 
{	
	
	@Test
	public void honey()
	{
		System.out.println("Honey"); 
	}
	
	@Test
	@Parameters({"URL"})	
	public void ParaMeter(@Optional("defaultURL") String urlname)
	{
		System.out.println(urlname);  
	}
	
	@Test
	@Parameters({"username", "password"})	
	public void Login(@Optional("defaultUsername") String user,  @Optional("defaultPassword") String pass) 
	{
		System.out.println(user);  
		System.out.println(pass);   

	}
	
}


