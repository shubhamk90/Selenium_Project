// By default, TestNg executes test methods within a class in alphabetical order [Not Strictly guaranteed] 


import org.testng.annotations.Test;
public class T11 
{
	@Test(timeOut = 2000) 
	public void Zebra() 
	{
		System.out.println("Name is Zebra"); 
	}
	
	@Test 
	public void yakir()
	{
		System.out.println("Name is yakir"); 
	}
	
	@Test (dependsOnMethods = {"Vince" , "yakir"}) 
	public void Shubham() 
	{
		System.out.println("Name is Shubham");
	}
	
	@Test
	public void Vince()
	{
		System.out.println("Name is Vince");
	}
	
	@Test
	public void Ehud()
	{
		System.out.println("Name is Ehud"); 
	}
	
	
	@Test(enabled = false) 
	public void skip()
	{
		System.out.println("We can skip this with the help of enabled attribute");
	}
	
	
	@Test
	public void Alley()
	{
		System.out.println("Name is Alley");
	} 
	
}



