import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class T7 
{
	@Test
	public void Apple()
	{
		System.out.println("Eat Apple");
	}
	
	@Test
	public void Mango()
	{
		System.out.println("Eat Mango");
	}
	
	@Test
	public void Banana()
	{
		System.out.println("Eat Banana"); 
	}
	
	@BeforeClass
	public void beforeClass()
	{
		System.out.println("I will execute before all the methods of the current class");
	}
	
}

