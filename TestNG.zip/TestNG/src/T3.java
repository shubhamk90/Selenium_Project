import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class T3 
{
	
	@AfterSuite
	public void aftersuite()
	{
		System.out.println("I will execute after all the <test> blocks in XML file");
	}
	
	
	@Test
	public void WebLoginCarLoan()
	{
		// Selenium
		System.out.println("WebCarLogin");
	}
	
	@Test
	public void MobileLoginCarLoan()
	{
		//Apppium
		System.out.println("MobileCarLogin");
	}
	
	@Test
	public void MobileSigninCarLoan()
	{
		//Apppium
		System.out.println("MobileCarSignIn");
	}
	
	@Test
	public void MobileSignOutCarLoan()
	{
		//Apppium 
		System.out.println("MobileCarSignOut");
	}
	
	
	@Test
	public void LoginApiCarLoan()
	{
		// rest API
		System.out.println("APICarLogin");
	} 
	
	
	
	@BeforeTest
	public void clean()
	{
		System.out.println("I execute first"); 
	}
}

