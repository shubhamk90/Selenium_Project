import org.testng.annotations.AfterGroups;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class T10 
{
	@AfterGroups("Smoke")
	public void AfterSmokeGroup()
	{
		System.out.println("Runs after Smoke group"); 
	}
	
	@Test
	public void NewDelhi()
	{ 
		System.out.println("NewDelhi");
	}
	
	@Test
	public void California()
	{
		System.out.println("California");
	}
	
	@Test(groups = {"Smoke"}) 
	public void Zurich()
	{
		System.out.println("Zurich"); 
	}	
}

