import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class T5
{
	@Test
	public void Morning()
	{
		System.out.println("Hey! Good Morning");
	}
	
	
	@BeforeMethod()
	public void beforemethod()
	{
		System.out.println("I will excute before each @test method in a class"); 
	}
	
	
	@Test 
	public void AfterNoon()
	{
		System.out.println("Hey! Good AfterNoon");
	}
	
}

