import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class T6 
{
	@AfterMethod
	public void aftermethod()
	{
		System.out.println("I will excute after each @test method in a class"); 
	}
	
	@Test
	public void Evening()
	{
		System.out.println("Hey! Good Evening");
	}
	
	@Test
	public void Night()
	{
		System.out.println("Hey! Good Night"); 
	}
}

