import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class T4
{
	@Test
	public void WebLoginHomeLoan()
	{
		// Selenium
		System.out.println("WebHomeLogin");
	}
	
	@Test 
	public void MobileLoginHomeLoan()
	{
		//Apppium
		System.out.println("MobileHomeLogin");
	}
	
	@Test
	public void LoginApiHomeLoan()
	{
		// rest API
		System.out.println("APIHomeLogin");
	} 
	
	@BeforeSuite
	public void beforesuite()
	{
		System.out.println("It will execute before all the <test> blocks in XML file");
	}
	
	
	
	
}

