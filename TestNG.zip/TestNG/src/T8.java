import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class T8
{
	@BeforeGroups("Smoke")
	public void BeforeSmokeGroup() 
	{
		System.out.println("Runs Before Smoke Group");
	} 
	
	@Test
	public void Sandwich()
	{
		System.out.println("Eat Sandwich");
	}
	
	@Test
	public void MangoShake()
	{
		System.out.println("MangoShake");
	}
	
	@Test(groups = {"Smoke"}) 
	public void BananaShake()
	{
		System.out.println("BananaShake"); 
	}
	
	@AfterClass
	public void afterClass()
	{
		System.out.println("I will execute after all the methods of the current class");
	}
	
}

